package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {


        try {

            // initilize JSONObject from json string
            JSONObject connect = new JSONObject(json);

            // name into a jsonobject
            JSONObject nameObject =connect.getJSONObject("name");

            // get mainName from nameObject
            String main = nameObject.getString("mainName");

            // get placeOfOrigin ,description,image , ingredients  from JSON
            String Origin = connect.getString("placeOfOrigin");
            String des = connect.getString("description");
            String img = connect.getString("image");

            List<String> ingred = new ArrayList<>();
            JSONArray ingredient =connect.getJSONArray("ingredients");
            for (int i=0; i<ingredient.length(); i++) {
                String ingredients = ingredient.getString(i);
                ingred.add(ingredients);
            }

            // get alsoKnownAs from nameObject
            List<String> alsoKnownAs = new ArrayList<>();
            JSONArray alsoKnown =nameObject.getJSONArray("alsoKnownAs");
            for (int i=0; i<alsoKnown.length(); i++) {
                String also = alsoKnown.getString(i);
                alsoKnownAs.add(also);
            }

            Sandwich  Object = new Sandwich (main , alsoKnownAs,Origin,des,img,ingred);
            return Object;

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
}
